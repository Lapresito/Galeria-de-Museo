#include "../include/visitaDia.h"

struct rep_visitadia{
};

TVisitaDia crearTVisitaDia(TFecha fecha, int N){
  return NULL;
}

void encolarGrupoTVisitaDia(TVisitaDia &visita, TGrupoABB grupo){
}

int cantidadGruposTVisitaDia(TVisitaDia visitaDia){
  return 0;
}

void imprimirTVisitaDia(TVisitaDia visitaDia){
}

TGrupoABB desencolarGrupoTVisitaDia(TVisitaDia &visitaDia){
    return NULL;  
}

void liberarTVisitaDia(TVisitaDia &visitaDia){
}

void invertirPrioridadTVisitaDia(TVisitaDia &visita) {
}

bool estaEnTVisitaDia(TVisitaDia visita, int id) {
  return false;
} 

float prioridadTVisitaDia(TVisitaDia visita, int id){
  return 0.0;
}

TGrupoABB masPrioritarioTVisitaDia(TVisitaDia visita){
	return NULL;
}


int maxGruposTVisitaDia(TVisitaDia visita){
  return 0;
}

TFecha fechaTVisitaDia(TVisitaDia visitaDia){
  return NULL;
}


