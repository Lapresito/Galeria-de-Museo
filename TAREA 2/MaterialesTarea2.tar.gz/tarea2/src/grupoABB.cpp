#include "../include/grupoABB.h"

struct rep_grupoABB {
    
};

TGrupoABB crearTGrupoABBVacio(){
    return NULL;
}

void insertarTVisitanteTGrupoABB(TGrupoABB &grupoABB, TVisitante visitante){
    
}

void imprimirTGrupoABB(TGrupoABB grupoABB){
    
}

bool existeTVisitanteTGrupoABB(TGrupoABB grupoABB, int idVisitante){
    return false;
}

TVisitante obtenerTVisitanteTGrupoABB(TGrupoABB grupoABB, int idVisitante){
    return NULL;
}

void removerTVisitanteTGrupoABB(TGrupoABB &grupoABB, int idVisitante){
    
}

nat alturaTGrupoABB(TGrupoABB grupoABB) {
    return 0;
}

int cantidadVisitantesTGrupoABB(TGrupoABB grupoABB){
    return 0;
}

float edadPromedioTGrupoABB(TGrupoABB grupoABB) {
    return 0.;
}

void liberarTGrupoABB(TGrupoABB &grupoABB){

}

TVisitante maxIdTVisitanteTGrupoABB(TGrupoABB grupoABB){
    return NULL;
}

TVisitante obtenerNesimoVisitanteTGrupoABB(TGrupoABB grupoABB, int n){
    return NULL;
}

