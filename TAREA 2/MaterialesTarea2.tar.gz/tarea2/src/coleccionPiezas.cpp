#include "../include/coleccionPiezas.h"

struct rep_coleccionpiezas{
    
};

TColeccionPiezas crearColeccionPiezasVacia(){ 
    return NULL; 
}

void insertarPiezaColeccionPiezas(TColeccionPiezas &coleccionPiezas, TPieza pieza){
    
}

void imprimirColeccionPiezas(TColeccionPiezas coleccionPiezas){
   
}

bool esVaciaColeccionPiezas(TColeccionPiezas piezas){
    return true;
}

bool existePiezaColeccionPiezas(TColeccionPiezas coleccionPiezas, int idPieza){
    return true;
}

TPieza obtenerPiezaColeccionPiezas(TColeccionPiezas coleccionPiezas, int idPieza){
    return NULL;
}

void removerPiezaColeccionPiezas(TColeccionPiezas &coleccionPiezas, int idPieza){
   
}

void liberarColeccionPiezas(TColeccionPiezas &coleccionPiezas){
    
}