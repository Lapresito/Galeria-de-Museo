#include "../include/visitante.h"

struct rep_visitante {
    
};

TVisitante crearTVisitante(int id, const char nombre[MAX_NOMBRE], const char apellido[MAX_APELLIDO], int edad){
    return NULL; 
}

void nombreTVisitante(TVisitante visitante, char nombre[MAX_NOMBRE]){

}

void apellidoTVisitante(TVisitante visitante, char apellido[MAX_APELLIDO]){

}

int idTVisitante(TVisitante visitante){
    return 0;
}

int edadTVisitante(TVisitante visitante){
    return 0;
}

void liberarTVisitante(TVisitante &visitante){

}

TVisitante copiarTVisitante(TVisitante visitante){
    return NULL;
}

void imprimirTVisitante(TVisitante visitante){

}

