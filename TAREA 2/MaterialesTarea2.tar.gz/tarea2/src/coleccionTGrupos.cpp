#include "../include/coleccionTGrupos.h"

struct rep_coleccionTGrupos {

};

TColeccionTGrupos crearTColeccionTGruposVacia(){
	return NULL;
}

void insertarGrupoTColeccionTGrupos(TColeccionTGrupos coleccion, TGrupoABB grupo){
	
}

void imprimirTColeccionTGrupos(TColeccionTGrupos coleccion){

}

void imprimirInvertidoTColeccionTGrupos(TColeccionTGrupos coleccion){

}

nat cantidadTGruposColeccionTGrupos(TColeccionTGrupos coleccion){
	return 0;
}

TGrupoABB obtenerNesimoColeccionTGrupos(TColeccionTGrupos coleccion, int n){
	return NULL;
}

TGrupoABB obtenerPrimeroColeccionTGrupos(TColeccionTGrupos coleccion){
	return NULL;
}

TGrupoABB removerUltimoColeccionTGrupos(TColeccionTGrupos coleccion){
	return NULL;
}

TGrupoABB removerNesimoColeccionTGrupos(TColeccionTGrupos coleccion, int n){
	return NULL;
}

void liberarTColeccionTGrupos(TColeccionTGrupos &coleccion){
	
}

TGrupoABB obtenerVisitantesRepetidos(TColeccionTGrupos coleccion){
	return NULL;
}

TVisitante visitanteMasRepetido(TColeccionTGrupos coleccion){
	return NULL;
}
