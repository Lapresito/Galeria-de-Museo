#include "../include/pieza.h"

struct rep_pieza {

};

TPieza crearTPieza(int identificador, const char nombrePieza[MAX_NOMBRE_PIEZA], const char nombreAutor[MAX_NOMBRE_AUTOR], const char apellidoAutor[MAX_APELLIDO_AUTOR], TFecha fechaCreacion){
    return NULL;
}

int idTPieza(TPieza pieza){ 
    return 0;
}

void imprimirTPieza(TPieza pieza){

}

void liberarTPieza(TPieza &pieza){

}


