#include "../include/galeria.h"


struct rep_galeria{
    TColeccionPiezas piezas;
    TFecha fechaActual;
    TListaExposiciones finalizadas;
    TListaExposiciones activas;
    TListaExposiciones futuras;
};


TGaleria crearTGaleria(TFecha fecha){
    TGaleria galeria = new rep_galeria;
    galeria->piezas = crearColeccionPiezasVacia();
    galeria->fechaActual = fecha;
    galeria->finalizadas = NULL;
    galeria->activas = NULL;
    galeria->futuras = NULL;
    return galeria; 
}

void agregarPiezaTGaleria(TGaleria galeria, TPieza pieza){
    insertarPiezaColeccionPiezas(galeria->piezas, pieza);
}


void agregarExposicionTGaleria(TGaleria galeria, TExposicion expo){
    // agrego la expiscion en la lista correspondiente
    if(compararTFechas(fechaFinTExposicion(expo), galeria->fechaActual) == -1){
        agregarExposicionTListaExposiciones(galeria->finalizadas, expo);
    }else if(compararTFechas(fechaInicioTExposicion(expo), galeria->fechaActual) == 1){
        agregarExposicionTListaExposiciones(galeria->futuras, expo);
    }else{
        agregarExposicionTListaExposiciones(galeria->activas, expo);
    }
}

void agregarPiezaAExposicionTGaleria(TGaleria galeria, int idPieza, int idExpo){
    // agrego la pieza en la exposicion correspondiente
    TExposicion aAgregar = obtenerExposicionTListaExposiciones(galeria->finalizadas, idExpo);
    if(aAgregar == NULL){
        aAgregar = obtenerExposicionTListaExposiciones(galeria->activas, idExpo);
    }
    if(aAgregar == NULL){
        aAgregar = obtenerExposicionTListaExposiciones(galeria->futuras, idExpo);
    }
    if(aAgregar != NULL){
        TPieza pieza = obtenerPiezaColeccionPiezas(galeria->piezas, idPieza);
        agregarATExposicion(aAgregar, pieza);
    }
}

void avanzarAFechaTGaleria(TGaleria galeria, TFecha fecha){
    // primero libero la fecha anterior y asigno la nueva.
    liberarTFecha(galeria->fechaActual);
    galeria->fechaActual = fecha;
    // unifico las listas para volver a separarlas con la nueva fecha
    TListaExposiciones finYAct = unirListaExposiciones(galeria->finalizadas, galeria->activas);
    TListaExposiciones listaGral = unirListaExposiciones(finYAct, galeria->futuras);
    // luego de unificada libero memoria de unificaciones sin perder las exposiciones con -false-
    liberarTListaExposiciones(galeria->activas, false);
    liberarTListaExposiciones(galeria->finalizadas, false);
    liberarTListaExposiciones(galeria->futuras, false);
    liberarTListaExposiciones(finYAct, false);
    // vuelvo a separar y asignar las listas.
    galeria->finalizadas = obtenerExposicionesFinalizadas(listaGral, fecha);
    galeria->activas = obtenerExposicionesActivas(listaGral, fecha);
    galeria->futuras = listaGral;

}

void imprimirExposicionesFinalizadasTGaleria(TGaleria galeria){
    imprimirTListaExposiciones(galeria->finalizadas);
}

void imprimirExposicionesActivasTGaleria(TGaleria galeria){
    imprimirTListaExposiciones(galeria->activas);
}

void imprimirExposicionesFuturasTGaleria(TGaleria galeria){
    imprimirTListaExposiciones(galeria->futuras);
}

bool esCompatibleExposicionTGaleria(TGaleria galeria, TExposicion expo){ 
    // si es compatible en las 3 listas retorno true.
    if(esCompatibleTListaExposiciones(galeria->finalizadas,expo)  && esCompatibleTListaExposiciones(galeria->activas,expo) && esCompatibleTListaExposiciones(galeria->futuras,expo)){
        return true;
    }else{
        return false;
    }
}

void liberarTGaleria(TGaleria &galeria){
    liberarColeccionPiezas(galeria->piezas);
    liberarTFecha(galeria->fechaActual);
    liberarTListaExposiciones(galeria->finalizadas, true);
    liberarTListaExposiciones(galeria->activas, true);
    liberarTListaExposiciones(galeria->futuras, true);
    delete galeria;
}
