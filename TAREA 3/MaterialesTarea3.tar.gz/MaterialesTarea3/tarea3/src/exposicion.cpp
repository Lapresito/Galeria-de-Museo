#include "../include/exposicion.h"

TExposicion crearTExposicion(int idExp, TFecha ini, TFecha fin, int cantMax){ return NULL; }

void agregarATExposicion(TExposicion &exp, TPieza p){}

bool perteneceATExposicion(TExposicion exp, TPieza p){ return false; }

int idTExposicion(TExposicion exp){ return 0; }

void imprimirTExposicion(TExposicion exp){}

TFecha fechaInicioTExposicion(TExposicion exp){ return NULL; }

TFecha fechaFinTExposicion(TExposicion exp){ return NULL; }

bool sonExposicionesCompatibles(TExposicion exp1, TExposicion exp2){ return false; }

void liberarTExposicion(TExposicion &exp){}

