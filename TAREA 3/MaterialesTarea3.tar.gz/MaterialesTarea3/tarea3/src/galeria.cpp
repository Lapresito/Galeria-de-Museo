#include "../include/galeria.h"

TGaleria crearTGaleria(TFecha fecha){ return NULL; }

void agregarPiezaTGaleria(TGaleria galeria, TPieza pieza){}

void agregarExposicionTGaleria(TGaleria galeria, TExposicion expo){}

void agregarPiezaAExposicionTGaleria(TGaleria galeria, int idPieza, int idExpo){}

void avanzarAFechaTGaleria(TGaleria galeria, TFecha fecha){}

void imprimirExposicionesFinalizadasTGaleria(TGaleria galeria){}

void imprimirExposicionesActivasTGaleria(TGaleria galeria){}

void imprimirExposicionesFuturasTGaleria(TGaleria galeria){}

bool esCompatibleExposicionTGaleria(TGaleria galeria, TExposicion expo){ return false; }

void liberarTGaleria(TGaleria &galeria){}
