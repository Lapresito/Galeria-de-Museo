#include "../include/visitaDia.h"

TVisitaDia crearTVisitaDia(TFecha fecha){ return NULL; }

void encolarGrupoTVisitaDia(TVisitaDia &visitaDia, TGrupoABB grupo){}

int cantidadGruposTVisitaDia(TVisitaDia visitaDia){ return 0; }

void imprimirVisitaDia(TVisitaDia visitaDia){}

TGrupoABB desencolarGrupoTVisitaDia(TVisitaDia &visitaDia){ return NULL; }

void liberarTVisitaDia(TVisitaDia &visitaDia){}

