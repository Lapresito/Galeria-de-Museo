#include "../include/conjuntoPiezas.h"

TConjuntoPiezas crearTConjuntoPiezas(int cantMax){ return NULL; }

bool esVacioTConjuntoPiezas(TConjuntoPiezas c){ return false; }

void insertarTConjuntoPiezas(TConjuntoPiezas &c, int id){}

void borrarDeTConjuntoPiezas(TConjuntoPiezas &c, int id){}

bool perteneceTConjuntoPiezas(TConjuntoPiezas c, int id){ return false; }

int cardinalTConjuntoPiezas(TConjuntoPiezas c){ return 0; }

int cantMaxTConjuntoPiezas(TConjuntoPiezas c){ return 0; }

void imprimirTConjuntoPiezas(TConjuntoPiezas c){}

void liberarTConjuntoPiezas(TConjuntoPiezas &c){}

TConjuntoPiezas unionTConjuntoPiezas(TConjuntoPiezas c1, TConjuntoPiezas c2){ return NULL; }

TConjuntoPiezas interseccionTConjuntoPiezas(TConjuntoPiezas c1, TConjuntoPiezas c2){ return NULL; }

TConjuntoPiezas diferenciaTConjuntoPiezas(TConjuntoPiezas c1, TConjuntoPiezas c2){ return NULL; }
